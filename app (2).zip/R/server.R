library(shiny)
library(jsonlite)

# Load modules
source("R/modules/filters.R")
source("R/modules/kpis.R")
source("data/database_operations.R")

server <- function(input, output, session) {
  
  # ============================================
  # DATA LOADING
  # ============================================
  
  # Load base sales data once
  base_sales_data <- reactive({
    cat("Loading base sales data...\n")
    get_data()
  })
  
  # ============================================
  # SEND FILTER OPTIONS TO JS
  # ============================================
  
  # Send filter options when requested
  observe({
    options <- get_filter_options()
    if (!is.null(options)) {
      session$sendCustomMessage("filter_options", options)
      cat("Filter options sent to JS\n")
    }
  })
  
  # ============================================
  # FILTER MANAGEMENT
  # ============================================
  
  # Create reactive filter values
  filters <- create_filter_reactives()
  
  # Listen to filter changes from JS
  observeEvent(input$dashboard_filters, {
    req(input$dashboard_filters)
    
    filter_data <- input$dashboard_filters
    
    cat("=== Filter Update from JS ===\n")
    cat("Start Date:", filter_data$startDate, "\n")
    cat("End Date:", filter_data$endDate, "\n")
    cat("Agent:", filter_data$agent, "\n")
    cat("Region:", filter_data$region, "\n")
    cat("Category:", filter_data$category, "\n")
    
    # Update reactive values
    filters$start_date <- filter_data$startDate
    filters$end_date <- filter_data$endDate
    filters$agent <- filter_data$agent
    filters$region <- filter_data$region
    filters$category <- filter_data$category
    
    # Check if filtered
    filters$is_filtered <- !is.null(filter_data$startDate) && filter_data$startDate != "" ||
      !is.null(filter_data$endDate) && filter_data$endDate != "" ||
      !is.null(filter_data$agent) && filter_data$agent != "" ||
      !is.null(filter_data$region) && filter_data$region != "" ||
      !is.null(filter_data$category) && filter_data$category != ""
    
    filters$last_updated <- Sys.time()
  })
  
  # Listen to reset from JS
  observeEvent(input$filters_reset, {
    cat("Filters reset requested from JS\n")
    
    filters$start_date <- NULL
    filters$end_date <- NULL
    filters$agent <- NULL
    filters$region <- NULL
    filters$category <- NULL
    filters$is_filtered <- FALSE
    filters$last_updated <- Sys.time()
  })
  
  # ============================================
  # FILTERED DATA
  # ============================================
  
  # Apply filters to data
  filtered_sales_data <- reactive({
    cat("Applying filters to data...\n")
    apply_filters_to_data(base_sales_data(), filters)
  })
  
  # ============================================
  # SEND KPI VALUES TO JS
  # ============================================
  
  # Calculate and send KPIs whenever filtered data changes
  observe({
    kpis <- calculate_kpis(filtered_sales_data())
    session$sendCustomMessage("update_kpis", kpis)
    cat("KPIs sent to JS\n")
  })
  
  # ============================================
  # SEND FILTER STATE TO JS
  # ============================================
  
  # Send current filter state
  observe({
    state <- get_filter_state(filters)
    session$sendCustomMessage("filter_state", state)
  })
  
  # ============================================
  # UI RENDERING (Static HTML)
  # ============================================
  
  # Render Header
  output$header <- renderUI({
    includeHTML("app/components/header.html")
  })
  
  # Render Sidebar
  output$sidebar <- renderUI({
    includeHTML("app/components/sidebar.html")
  })
  
  # Render Dashboard Page
  output$dashboard <- renderUI({
    cat("Rendering dashboard page\n")
    includeHTML("app/dashboard.html")
  })
  
  # Render Sales Agents Page
  output$sales_agents <- renderUI({
    cat("Rendering sales agents page\n")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Sales Agents"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Sales Agents page - Coming soon...")
      )
    )
  })
  
  # Render Product Performance Page
  output$product_performance <- renderUI({
    cat("Rendering product performance page\n")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Product Performance"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Product Performance page - Coming soon...")
      )
    )
  })
  
  # Render Sales Forecast Page
  output$sales_forecast <- renderUI({
    cat("Rendering sales forecast page\n")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Sales Forecast"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Sales Forecast page - Coming soon...")
      )
    )
  })
  
  # Render Data Page
  output$data_page <- renderUI({
    cat("Rendering data page\n")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Data"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Data page - Coming soon...")
      )
    )
  })
  
  # Render Documentation Page
  output$documentation <- renderUI({
    cat("Rendering documentation page\n")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Documentation"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Documentation page - Coming soon...")
      )
    )
  })
  
  # ============================================
  # DEBUG OUTPUT
  # ============================================
  
  # Output current filter values for debugging
  output$debug_filters <- renderPrint({
    list(
      start_date = filters$start_date,
      end_date = filters$end_date,
      agent = filters$agent,
      region = filters$region,
      category = filters$category,
      is_filtered = filters$is_filtered,
      filtered_rows = nrow(filtered_sales_data())
    )
  })
}