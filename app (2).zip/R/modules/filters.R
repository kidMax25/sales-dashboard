# ============================================
# FILTER MODULE - Pure Data Logic (No UI)
# ============================================
# Extracts unique values from correct columns:
# - Sales Agent: First Name + Last Name
# - Region: Ship City
# - Category: Category

library(shiny)
library(tidyverse)

source("data/database_operations.R")

# ============================================
# GET FILTER OPTIONS FROM DATA
# ============================================

get_filter_options <- function() {
  tryCatch({
    sales_data <- get_data()
    
    if (is.null(sales_data) || nrow(sales_data) == 0) {
      return(NULL)
    }
    
    cat("Extracting filter options from sales_data...\n")
    
    # Extract unique agents (First Name + Last Name)
    agents <- sales_data %>%
      distinct(`Employee ID`, `First Name`, `Last Name`) %>%
      filter(!is.na(`Employee ID`), 
             !is.na(`First Name`), 
             !is.na(`Last Name`)) %>%
      mutate(
        value = as.character(`Employee ID`),
        label = paste(`First Name`, `Last Name`)
      ) %>%
      arrange(label) %>%
      select(value, label)
    
    cat("  - Agents extracted:", nrow(agents), "\n")
    
    # Extract unique regions (Ship City)
    regions <- sales_data %>%
      distinct(`Ship City`) %>%
      filter(!is.na(`Ship City`), `Ship City` != "") %>%
      rename(value = `Ship City`) %>%
      mutate(label = value) %>%
      arrange(value)
    
    cat("  - Regions (Ship City) extracted:", nrow(regions), "\n")
    
    # Extract unique categories
    categories <- sales_data %>%
      distinct(Category) %>%
      filter(!is.na(Category), Category != "") %>%
      rename(value = Category) %>%
      mutate(label = value) %>%
      arrange(value)
    
    cat("  - Categories extracted:", nrow(categories), "\n")
    
    # Get date range from Order Date
    date_range <- list(
      min_date = as.character(min(sales_data$`Order Date`, na.rm = TRUE)),
      max_date = as.character(max(sales_data$`Order Date`, na.rm = TRUE))
    )
    
    cat("  - Date range:", date_range$min_date, "to", date_range$max_date, "\n")
    
    # Build options list
    options <- list(
      agents = agents,
      regions = regions,
      categories = categories,
      date_range = date_range
    )
    
    return(options)
    
  }, error = function(e) {
    cat("Error getting filter options:", e$message, "\n")
    return(NULL)
  })
}

# ============================================
# CREATE FILTER REACTIVE VALUES
# ============================================

create_filter_reactives <- function() {
  reactiveValues(
    start_date = NULL,
    end_date = NULL,
    agent = NULL,
    region = NULL,
    category = NULL,
    is_filtered = FALSE,
    last_updated = Sys.time()
  )
}

# ============================================
# APPLY FILTERS TO DATA
# ============================================

apply_filters_to_data <- function(sales_data, filters) {
  
  if (is.null(sales_data) || nrow(sales_data) == 0) {
    return(NULL)
  }
  
  filtered_data <- sales_data
  original_rows <- nrow(filtered_data)
  
  # Date range filter (Order Date)
  if (!is.null(filters$start_date) && filters$start_date != "") {
    filtered_data <- filtered_data %>%
      filter(`Order Date` >= as.Date(filters$start_date))
    cat("  - After start_date filter:", nrow(filtered_data), "rows\n")
  }
  
  if (!is.null(filters$end_date) && filters$end_date != "") {
    filtered_data <- filtered_data %>%
      filter(`Order Date` <= as.Date(filters$end_date))
    cat("  - After end_date filter:", nrow(filtered_data), "rows\n")
  }
  
  # Agent filter (Employee ID)
  if (!is.null(filters$agent) && filters$agent != "") {
    filtered_data <- filtered_data %>%
      filter(`Employee ID` == as.numeric(filters$agent))
    cat("  - After agent filter:", nrow(filtered_data), "rows\n")
  }
  
  # Region filter (Ship City)
  if (!is.null(filters$region) && filters$region != "") {
    filtered_data <- filtered_data %>%
      filter(`Ship City` == filters$region)
    cat("  - After region filter:", nrow(filtered_data), "rows\n")
  }
  
  # Category filter
  if (!is.null(filters$category) && filters$category != "") {
    filtered_data <- filtered_data %>%
      filter(Category == filters$category)
    cat("  - After category filter:", nrow(filtered_data), "rows\n")
  }
  
  cat("Data filtered:", original_rows, "->", nrow(filtered_data), "rows\n")
  
  return(filtered_data)
}

# ============================================
# GET CURRENT FILTER STATE
# ============================================

get_filter_state <- function(filters) {
  list(
    start_date = filters$start_date %||% "",
    end_date = filters$end_date %||% "",
    agent = filters$agent %||% "",
    region = filters$region %||% "",
    category = filters$category %||% "",
    is_filtered = filters$is_filtered,
    last_updated = format(filters$last_updated, "%Y-%m-%d %H:%M:%S")
  )
}