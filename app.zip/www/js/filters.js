/**
 * ============================================
 * FILTERS.JS - Complete Filter Management
 * ============================================
 * Handles all filter UI interactions and communicates with Shiny
 * Populates dropdowns from R data:
 * - Sales Agent: First Name + Last Name
 * - Region: Ship City
 * - Category: Category
 */

// ============================================
// GLOBAL FILTER STATE
// ============================================
const FilterState = {
    startDate: '',
    endDate: '',
    agent: '',       // Employee ID
    region: '',      // Ship City
    category: '',    // Category
    
    /**
     * Get current state as object
     * @returns {Object} Current filter values
     */
    getState() {
        return {
            startDate: this.startDate,
            endDate: this.endDate,
            agent: this.agent,
            region: this.region,
            category: this.category
        };
    },
    
    /**
     * Update state from DOM and send to Shiny
     */
    updateState() {
        // Read values from DOM elements
        this.startDate = document.getElementById('start_date')?.value || '';
        this.endDate = document.getElementById('end_date')?.value || '';
        this.agent = document.getElementById('agent_filter')?.value || '';
        this.region = document.getElementById('region_filter')?.value || '';
        this.category = document.getElementById('category_filter')?.value || '';
        
        // Log current state for debugging
        console.log('=== Filter State Updated ===');
        console.log('Start Date:', this.startDate);
        console.log('End Date:', this.endDate);
        console.log('Agent (Employee ID):', this.agent);
        console.log('Region (Ship City):', this.region);
        console.log('Category:', this.category);
        
        // Send to Shiny
        this.sendToShiny();
    },
    
    /**
     * Send current state to Shiny server
     */
    sendToShiny() {
        if (typeof Shiny !== 'undefined' && Shiny.setInputValue) {
            Shiny.setInputValue('dashboard_filters', this.getState(), {priority: 'event'});
            console.log('✓ Filter state sent to Shiny');
        } else {
            console.warn('Shiny not available - cannot send filter state');
        }
    },
    
    /**
     * Reset all filters to default state
     */
    reset() {
        console.log('Resetting all filters...');
        
        // Reset internal state
        this.startDate = '';
        this.endDate = '';
        this.agent = '';
        this.region = '';
        this.category = '';
        
        // Reset DOM elements
        const startDate = document.getElementById('start_date');
        const endDate = document.getElementById('end_date');
        const agentFilter = document.getElementById('agent_filter');
        const regionFilter = document.getElementById('region_filter');
        const categoryFilter = document.getElementById('category_filter');
        
        if (startDate) startDate.value = '';
        if (endDate) endDate.value = '';
        if (agentFilter) agentFilter.value = '';
        if (regionFilter) regionFilter.value = '';
        if (categoryFilter) categoryFilter.value = '';
        
        // Reset agent profile to default if function exists
        if (typeof updateAgentProfile === 'function') {
            updateAgentProfile('agent1');
        }
        
        console.log('✓ Filters reset to default');
        
        // Send reset event and updated state to Shiny
        if (typeof Shiny !== 'undefined' && Shiny.setInputValue) {
            Shiny.setInputValue('filters_reset', Math.random(), {priority: 'event'});
            Shiny.setInputValue('dashboard_filters', this.getState(), {priority: 'event'});
            console.log('✓ Reset event sent to Shiny');
        }
    },
    
    /**
     * Check if any filter is active
     * @returns {boolean}
     */
    isFiltered() {
        return this.startDate !== '' || 
               this.endDate !== '' || 
               this.agent !== '' || 
               this.region !== '' || 
               this.category !== '';
    }
};

// ============================================
// POPULATE FILTER OPTIONS FROM SHINY DATA
// ============================================

/**
 * Populate filter dropdowns with data from Shiny
 * @param {Object} options - Filter options from R
 */
function populateFilterOptions(options) {
    console.log('📥 Populating filter options from Shiny data');
    
    if (!options) {
        console.error('No options provided');
        return;
    }
    
    // Populate Sales Agents (First Name + Last Name)
    if (options.agents && Array.isArray(options.agents)) {
        const agentFilter = document.getElementById('agent_filter');
        if (agentFilter) {
            // Clear existing and add "All Agents"
            agentFilter.innerHTML = '<option value="">All Agents</option>';
            
            // Add agents from data
            options.agents.forEach(agent => {
                const option = document.createElement('option');
                option.value = agent.value;  // Employee ID
                option.textContent = agent.label;  // First Name + Last Name
                agentFilter.appendChild(option);
            });
            
            console.log('  ✓ Sales Agents populated:', options.agents.length, 'items');
        } else {
            console.warn('  ⚠ Agent filter element not found');
        }
    }
    
    // Populate Regions (Ship City)
    if (options.regions && Array.isArray(options.regions)) {
        const regionFilter = document.getElementById('region_filter');
        if (regionFilter) {
            // Clear existing and add "All Cities"
            regionFilter.innerHTML = '<option value="">All Cities</option>';
            
            // Add cities from data
            options.regions.forEach(region => {
                const option = document.createElement('option');
                option.value = region.value;  // Ship City
                option.textContent = region.label;  // Ship City
                regionFilter.appendChild(option);
            });
            
            console.log('  ✓ Ship Cities populated:', options.regions.length, 'items');
        } else {
            console.warn('  ⚠ Region filter element not found');
        }
    }
    
    // Populate Categories
    if (options.categories && Array.isArray(options.categories)) {
        const categoryFilter = document.getElementById('category_filter');
        if (categoryFilter) {
            // Clear existing and add "All Categories"
            categoryFilter.innerHTML = '<option value="">All Categories</option>';
            
            // Add categories from data
            options.categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.value;  // Category
                option.textContent = category.label;  // Category
                categoryFilter.appendChild(option);
            });
            
            console.log('  ✓ Categories populated:', options.categories.length, 'items');
        } else {
            console.warn('  ⚠ Category filter element not found');
        }
    }
    
    // Set date range limits (Order Date)
    if (options.date_range) {
        const startDate = document.getElementById('start_date');
        const endDate = document.getElementById('end_date');
        
        if (startDate && options.date_range.min_date) {
            startDate.min = options.date_range.min_date;
            startDate.max = options.date_range.max_date;
        }
        
        if (endDate && options.date_range.max_date) {
            endDate.min = options.date_range.min_date;
            endDate.max = options.date_range.max_date;
        }
        
        console.log('  ✓ Date range set:', options.date_range.min_date, 'to', options.date_range.max_date);
    }
    
    console.log('✓ All filter options populated successfully');
}

// ============================================
// UPDATE KPI DISPLAY
// ============================================

/**
 * Update KPI cards with new values from Shiny
 * @param {Object} kpis - KPI data from R
 */
function updateKPIDisplay(kpis) {
    console.log('📊 Updating KPI display');
    
    if (!kpis) {
        console.error('No KPI data provided');
        return;
    }
    
    // Update Total Revenue
    if (kpis.total_revenue) {
        const revenueValue = document.querySelector('.div4 .grid > div:nth-child(1) .text-2xl');
        const revenueSubtitle = document.querySelector('.div4 .grid > div:nth-child(1) .text-xs');
        
        if (revenueValue) {
            revenueValue.textContent = kpis.total_revenue.formatted;
            console.log('  ✓ Total Revenue:', kpis.total_revenue.formatted);
        }
        
        if (revenueSubtitle) {
            revenueSubtitle.textContent = kpis.total_revenue.subtitle;
        }
    }
    
    // Update Total Orders
    if (kpis.total_orders) {
        const ordersValue = document.querySelector('.div4 .grid > div:nth-child(2) .text-2xl');
        const ordersSubtitle = document.querySelector('.div4 .grid > div:nth-child(2) .text-xs');
        
        if (ordersValue) {
            ordersValue.textContent = kpis.total_orders.formatted;
            console.log('  ✓ Total Orders:', kpis.total_orders.formatted);
        }
        
        if (ordersSubtitle) {
            ordersSubtitle.textContent = kpis.total_orders.subtitle;
        }
    }
    
    // Update Average Order Value
    if (kpis.average_order_value) {
        const avgValue = document.querySelector('.div4 .grid > div:nth-child(3) .text-2xl');
        const avgSubtitle = document.querySelector('.div4 .grid > div:nth-child(3) .text-xs');
        
        if (avgValue) {
            avgValue.textContent = kpis.average_order_value.formatted;
            console.log('  ✓ Avg Order Value:', kpis.average_order_value.formatted);
        }
        
        if (avgSubtitle) {
            avgSubtitle.textContent = kpis.average_order_value.subtitle;
        }
    }
    
    // Update Total Shipped
    if (kpis.total_shipped) {
        const shippedValue = document.querySelector('.div4 .grid > div:nth-child(4) .text-2xl');
        const shippedSubtitle = document.querySelector('.div4 .grid > div:nth-child(4) .text-xs');
        
        if (shippedValue) {
            shippedValue.textContent = kpis.total_shipped.formatted;
            console.log('  ✓ Total Shipped:', kpis.total_shipped.formatted);
        }
        
        if (shippedSubtitle) {
            shippedSubtitle.textContent = kpis.total_shipped.subtitle;
        }
    }
    
    console.log('✓ KPIs updated successfully');
}

// ============================================
// SHINY MESSAGE HANDLERS
// ============================================

if (typeof Shiny !== 'undefined') {
    console.log('✓ Shiny detected - Setting up message handlers');
    
    /**
     * Receive filter options from Shiny
     */
    Shiny.addCustomMessageHandler('filter_options', function(options) {
        console.log('📨 Received filter options from Shiny');
        populateFilterOptions(options);
    });
    
    /**
     * Receive KPI updates from Shiny
     */
    Shiny.addCustomMessageHandler('update_kpis', function(kpis) {
        console.log('📨 Received KPI update from Shiny');
        updateKPIDisplay(kpis);
    });
    
    /**
     * Receive filter state from Shiny (for synchronization)
     */
    Shiny.addCustomMessageHandler('filter_state', function(state) {
        console.log('📨 Received filter state from Shiny:', state);
    });
    
} else {
    console.warn('⚠ Shiny not detected - Running in standalone mode');
}

// ============================================
// INITIALIZE EVENT LISTENERS
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Filter system initializing...');
    
    // List of all filter input IDs
    const filterInputs = [
        'start_date',
        'end_date',
        'agent_filter',
        'region_filter',
        'category_filter'
    ];
    
    // Bind change events to all filter inputs
    filterInputs.forEach(filterId => {
        const element = document.getElementById(filterId);
        
        if (element) {
            element.addEventListener('change', function() {
                console.log('🔄 Filter changed:', filterId, '=', this.value);
                FilterState.updateState();
            });
            console.log('  ✓ Event listener bound to:', filterId);
        } else {
            console.warn('  ⚠ Filter element not found:', filterId);
        }
    });
    
    // Bind reset button
    const resetButton = document.getElementById('reset-filters');
    if (resetButton) {
        resetButton.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('🔄 Reset button clicked');
            FilterState.reset();
        });
        console.log('  ✓ Reset button bound');
    } else {
        console.warn('  ⚠ Reset button not found (#reset-filters)');
    }
    
    console.log('✓ Filter system initialized');
    
    // Request initial data from Shiny after a short delay
    setTimeout(function() {
        if (typeof Shiny !== 'undefined') {
            console.log('📤 Requesting initial data from Shiny...');
            FilterState.sendToShiny(); // Trigger initial load
        }
    }, 500);
});

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Show notification to user (can be enhanced with a toast library)
 * @param {string} message - Notification message
 * @param {string} type - Notification type (info, success, warning, error)
 */
function showNotification(message, type = 'info') {
    console.log(`[${type.toUpperCase()}] ${message}`);
    // You can enhance this with a visual notification library like toastify
}

/**
 * Get filter summary as human-readable text
 * @returns {string}
 */
function getFilterSummary() {
    const state = FilterState.getState();
    const parts = [];
    
    if (state.startDate) parts.push(`From: ${state.startDate}`);
    if (state.endDate) parts.push(`To: ${state.endDate}`);
    if (state.agent) parts.push(`Agent ID: ${state.agent}`);
    if (state.region) parts.push(`City: ${state.region}`);
    if (state.category) parts.push(`Category: ${state.category}`);
    
    return parts.length > 0 ? parts.join(', ') : 'No filters active';
}

// ============================================
// EXPORT FOR GLOBAL ACCESS
// ============================================
window.FilterState = FilterState;
window.getFilterSummary = getFilterSummary;

// Log that filters.js is loaded
console.log('✓ filters.js loaded successfully');