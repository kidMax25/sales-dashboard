get_data <- function() {
  source("data/database_connect.R")
  loader <- tryCatch({
    database_connect()
    cat("Data Connection Succeffull")
    TRUE
  }, error = function(e) {
    cat("Failed to load data, error: ", e$message)
    FALSE
  })
  
  if (loader) {
    data <- readRDS("data//data.rds")
    cat("Data Loaded Succefully")
  } else {
    cat("Failed to Load Data")
  }
  
  ## Unnest Data
  require(pacman)
  p_load(tidyverse)
  
  data_unlist <- map(data, as_tibble)
  
  list2env(data_unlist, envir = .GlobalEnv)
  
  ## Sales Data
  sales_data <- Orders |>
    left_join(`Order Details`, by = c("Order ID" = "Order ID")) |>
    left_join(Products, by = c("Product ID" = "ID")) |>
    left_join(Employees, by = c("Employee ID" = "ID"))
  
  ## KPIs
  get_kpis <- function() {
    total_revenue <- sales_data |>
      mutate(line_total = Quantity * `Unit Price` * (1 - Discount)) |>
      summarise(total = sum(line_total, na.rm = TRUE))
    
    total_orders <- Orders |> nrow()
    
    average_order_value <- sales_data |>
      group_by(`Order ID`) |>
      summarise(order_total = sum(Quantity * `Unit Price` * (1 - Discount))) |>
      summarise(average = mean(order_total, na.rm = TRUE))
    
    total_shipped <- Orders %>%
      filter(!is.na(`Shipped Date`)) %>%
      nrow()
    
    kpis = list(
      "Total Revenue" = total_revenue,
      "Total Orders" = total_orders,
      "Average Order Value" = average_order_value,
      "Total Shipped" = total_shipped
    )
    
    return(kpis)
  }
  
  ## Agent Information
  agent_sales <- sales_data |> 
    filter()
  
}