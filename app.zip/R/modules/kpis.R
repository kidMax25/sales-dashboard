
library(shiny)
library(tidyverse)

source("data/database_operations.R")


calculate_kpis <- function(filtered_data) {
  
  kpis <- get_kpis(filtered_data)
  
  # Format for display
  kpi_values <- list(
    total_revenue = list(
      raw = kpis$total_revenue,
      formatted = scales::dollar(kpis$total_revenue, accuracy = 0.1, scale = 1e-6, suffix = "M"),
      subtitle = paste(scales::comma(kpis$total_orders), "orders")
    ),
    total_orders = list(
      raw = kpis$total_orders,
      formatted = scales::comma(kpis$total_orders),
      subtitle = "Unique orders"
    ),
    average_order_value = list(
      raw = kpis$average_order_value,
      formatted = scales::dollar(kpis$average_order_value),
      subtitle = "Per order"
    ),
    total_shipped = list(
      raw = kpis$total_shipped,
      formatted = scales::comma(kpis$total_shipped),
      percentage = if (kpis$total_orders > 0) {
        round((kpis$total_shipped / kpis$total_orders) * 100)
      } else {
        0
      },
      subtitle = paste0(
        if (kpis$total_orders > 0) {
          round((kpis$total_shipped / kpis$total_orders) * 100)
        } else {
          0
        },
        "% of total orders"
      )
    )
  )
  
  return(kpi_values)
}