library(shiny)

server <- function(input, output, session) {
  
  # Render Header
  output$header <- renderUI({
    includeHTML("app/components/header.html")
  })
  
  # Render Sidebar
  output$sidebar <- renderUI({
    includeHTML("app/components/sidebar.html")
  })
  
  # Render Dashboard Page
  output$dashboard <- renderUI({
    print("Rendering dashboard page")
    includeHTML("app/dashboard.html")
  })
  
  # Render Sales Agents Page
  output$sales_agents <- renderUI({
    print("Rendering sales agents page")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Sales Agents"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Sales Agents page - Coming soon...")
      )
    )
  })
  
  # Render Product Performance Page
  output$product_performance <- renderUI({
    print("Rendering product performance page")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Product Performance"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Product Performance page - Coming soon...")
      )
    )
  })
  
  # Render Sales Forecast Page
  output$sales_forecast <- renderUI({
    print("Rendering sales forecast page")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Sales Forecast"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Sales Forecast page - Coming soon...")
      )
    )
  })
  
  # Render Data Page
  output$data_page <- renderUI({
    print("Rendering data page")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Data"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Data page - Coming soon...")
      )
    )
  })
  
  # Render Documentation Page
  output$documentation <- renderUI({
    print("Rendering documentation page")
    tags$div(
      class = "max-w-7xl mx-auto",
      tags$h2(class = "text-3xl font-bold text-gray-800 mb-6", "Documentation"),
      tags$div(
        class = "bg-white rounded-lg shadow-sm border border-gray-200 p-8",
        tags$p(class = "text-gray-600", "Documentation page - Coming soon...")
      )
    )
  })
  
  # Listen to filter changes
  observeEvent(input$dashboard_filters, {
    filters <- input$dashboard_filters
    cat("=== Dashboard Filters Changed ===\n")
    cat("Start Date:", filters$startDate, "\n")
    cat("End Date:", filters$endDate, "\n")
    cat("Agent:", filters$agent, "\n")
    cat("Region:", filters$region, "\n")
    cat("Category:", filters$category, "\n")
    
    # Here you would update your data based on filters
    # Example: filtered_data <- filterData(filters)
  })
  
  # Listen to filter reset
  observeEvent(input$filters_reset, {
    cat("Filters reset\n")
    # Reset your data to default state
  })
  
}